import SwiftUI

final class IScreenAppPlugin: BaseAppPlugin {
    override class var id: String { "iscreen" }
    override class var name: String { "iScreen" }
    override class var icon: String { "square.grid.2x2.fill" }
    override class var colorName: String { "purple" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(IScreenView(show: show))
    }
}

struct IScreenView: View {
    @Binding var show: Bool
    
    @StateObject private var viewModel = IScreenViewModel()
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared
    
    var activeEditWidgetBinding: Binding<Bool> {
        Binding(
            get: { viewModel.activeEditWidgetID != nil },
            set: { if !$0 { viewModel.activeEditWidgetID = nil } }
        )
    }
    
    private var activeEditingItemBinding: Binding<WidgetDefinition?> {
        Binding(
            get: {
                guard let id = viewModel.activeEditWidgetID else { return nil }
                return registry.registeredWidgets.first(where: { $0.id == id })
            },
            set: { viewModel.activeEditWidgetID = $0?.id }
        )
    }
    
    var body: some View {
        NavigationStack {
            TabView(selection: $viewModel.currentTab) {
                IScreenHomeView(viewModel: viewModel)
                    .tabItem {
                        Image(systemName: "sparkles.rectangle.stack.fill")
                        Text("首页".tr)
                    }
                    .tag(0)
                
                IScreenIconStudioView()
                    .tabItem {
                        Image(systemName: "photo.stack.fill")
                        Text("图标".tr)
                    }
                    .tag(1)
                
                IScreenWorkshopView()
                    .tabItem {
                        Image(systemName: "hammer.fill")
                        Text("工坊".tr)
                    }
                    .tag(2)
                
                IScreenProfileView(viewModel: viewModel)
                    .tabItem {
                        Image(systemName: "person.crop.circle.fill")
                        Text("更多".tr)
                    }
                    .tag(3)
            }
            .navigationTitle(navigationTitle(for: viewModel.currentTab))
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
        .sheet(item: activeEditingItemBinding) { widgetDef in
            widgetDef.editSheetView(activeEditWidgetBinding)
        }
    }
    
    private func navigationTitle(for tab: Int) -> String {
        switch tab {
        case 0: return "" // 🌟 首页由页面自定义左上大标题“组件”
        case 1: return "图标灵动工坊".tr
        case 2: return "我的自制库".tr
        case 3: return "个人中心".tr
        default: return "iScreen"
        }
    }
}
