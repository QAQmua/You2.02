// 📄 独立文件：IScreenApp/IconBorderStudio.swift (图标全局边框引擎 · 方案C仿真工坊)
import SwiftUI

// MARK: - 1. 描边模式枚举
public enum IconBorderType: String, CaseIterable, Identifiable, Codable {
    case inner = "inner" // 精工内嵌 (内描边)
    case outer = "outer" // 贴纸轮廓 (外描边)
    
    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .inner: return "内描边 (精工内嵌)".tr
        case .outer: return "外描边 (立体贴纸)".tr
        }
    }
}

// MARK: - 2. 全局独立数据管理中心 (单例 · 零侵入持久化)
@MainActor
public final class IconBorderManager: ObservableObject {
    public static let shared = IconBorderManager()
    
    private let kEnabled = "App_IconBorder_IsEnabled"
    private let kType = "App_IconBorder_Type"
    private let kWidth = "App_IconBorder_Width"
    private let kOpacity = "App_IconBorder_Opacity"
    private let kColorHex = "App_IconBorder_ColorHex"
    
    @Published public var isEnabled: Bool {
        didSet { UserDefaults.standard.set(isEnabled, forKey: kEnabled) }
    }
    @Published public var borderType: IconBorderType {
        didSet { UserDefaults.standard.set(borderType.rawValue, forKey: kType) }
    }
    @Published public var width: Double {
        didSet { UserDefaults.standard.set(width, forKey: kWidth) }
    }
    @Published public var opacity: Double {
        didSet { UserDefaults.standard.set(opacity, forKey: kOpacity) }
    }
    @Published public var colorHex: String {
        didSet { UserDefaults.standard.set(colorHex, forKey: kColorHex) }
    }
    
    public var currentColor: Color { Color(hex: colorHex) }
    
    public init() {
        self.isEnabled = UserDefaults.standard.bool(forKey: kEnabled)
        let typeRaw = UserDefaults.standard.string(forKey: kType) ?? IconBorderType.inner.rawValue
        self.borderType = IconBorderType(rawValue: typeRaw) ?? .inner
        let savedWidth = UserDefaults.standard.object(forKey: kWidth) as? Double
        self.width = savedWidth ?? 1.2
        let savedOpacity = UserDefaults.standard.object(forKey: kOpacity) as? Double
        self.opacity = savedOpacity ?? 0.85
        self.colorHex = UserDefaults.standard.string(forKey: kColorHex) ?? "#FFFFFF"
    }
    
    public func resetToDefaults() {
        isEnabled = false
        borderType = .inner
        width = 1.2
        opacity = 0.85
        colorHex = "#FFFFFF"
    }
}

// MARK: - 3. 干净的通用图标描边渲染器 (Modifier)
public struct IconBorderModifier: ViewModifier {
    @ObservedObject var manager = IconBorderManager.shared
    let cornerRadius: CGFloat
    
    public func body(content: Content) -> some View {
        let s = uiScale
        let r = cornerRadius * s
        let effectiveColor = manager.currentColor.opacity(manager.opacity)
        let strokeW = CGFloat(manager.width) * s
        
        Group {
            if manager.isEnabled {
                switch manager.borderType {
                case .inner:
                    // 🌟 内描边：收纳在圆角之内，极致平滑贴合，不溢出边界
                    content
                        .overlay(
                            RoundedRectangle(cornerRadius: r, style: .continuous)
                                .strokeBorder(effectiveColor, lineWidth: strokeW)
                        )
                case .outer:
                    // 🌟 外描边（贴纸算法）：图标微缩容纳，外部形成强烈的贴纸包边感
                    content
                        .padding(strokeW * 0.7)
                        .background(
                            RoundedRectangle(cornerRadius: r + (strokeW * 0.3), style: .continuous)
                                .stroke(effectiveColor, lineWidth: strokeW)
                        )
                }
            } else {
                content
            }
        }
    }
}

extension View {
    public func applyIconBorder(cornerRadius: CGFloat = 15.5) -> some View {
        self.modifier(IconBorderModifier(cornerRadius: cornerRadius))
    }
}

// MARK: - 4. 方案 C：独立全屏仿真画板与工坊大弹窗
public struct IconBorderStudioSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var manager = IconBorderManager.shared
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    private let presetColors = [
        "#FFFFFF", "#000000", "#007AFF", "#34C759", 
        "#FF2D55", "#AF52DE", "#FF9500", "#5AC8FA"
    ]
    
    public var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    // 🖼️ 顶部：真实壁纸 1:1 仿真画板 (同时展示桌面网格与 Dock 栏)
                    canvasPreviewBox
                        .padding(.top, 10)
                    
                    // 🎛️ 核心控制器卡片
                    VStack(alignment: .leading, spacing: 16) {
                        // 1. 总开关
                        Toggle(isOn: $manager.isEnabled.animation(.spring(response: 0.3, dampingFraction: 0.8))) {
                            Label("启用全局图标边框".tr, systemImage: "square.dashed")
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                        
                        if manager.isEnabled {
                            Divider()
                            
                            // 2. 内描边 vs 外描边 分段器
                            VStack(alignment: .leading, spacing: 8) {
                                Text("描边形态".tr)
                                    .font(.system(size: 13, weight: appearance.systemFontWeight))
                                    .foregroundColor(.secondary)
                                
                                Picker("", selection: $manager.borderType) {
                                    ForEach(IconBorderType.allCases) { type in
                                        Text(type.title).tag(type)
                                    }
                                }
                                .pickerStyle(.segmented)
                            }
                            
                            Divider()
                            
                            // 3. 粗细调节
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("描边粗细".tr)
                                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.1f pt", manager.width))
                                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                                        .foregroundColor(.secondary)
                                }
                                
                                HStack(spacing: 12) {
                                    Button(action: {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        manager.width = max(0.5, ((manager.width - 0.1) * 10).rounded() / 10)
                                    }) {
                                        Image(systemName: "minus")
                                            .font(.system(size: 11, weight: .bold))
                                            .foregroundColor(.secondary)
                                            .frame(width: 26, height: 26)
                                            .background(Color(UIColor.tertiarySystemFill))
                                            .clipShape(Circle())
                                    }
                                    .buttonStyle(.plain)
                                    
                                    Slider(value: $manager.width, in: 0.5...4.5, step: 0.1)
                                    
                                    Button(action: {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        manager.width = min(4.5, ((manager.width + 0.1) * 10).rounded() / 10)
                                    }) {
                                        Image(systemName: "plus")
                                            .font(.system(size: 11, weight: .bold))
                                            .foregroundColor(.secondary)
                                            .frame(width: 26, height: 26)
                                            .background(Color(UIColor.tertiarySystemFill))
                                            .clipShape(Circle())
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            
                            Divider()
                            
                            // 4. 透明度调节
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("不透明度".tr)
                                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(manager.opacity * 100))%")
                                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                                        .foregroundColor(.secondary)
                                }
                                Slider(value: $manager.opacity, in: 0.1...1.0, step: 0.05)
                            }
                            
                            Divider()
                            
                            // 5. 颜色预设与自选
                            WidgetColorPaletteRow(
                                title: "边框颜色".tr,
                                selectedHex: manager.colorHex,
                                presets: presetColors,
                                currentColor: manager.currentColor,
                                onSelectHex: { manager.colorHex = $0 },
                                onPickColor: { manager.colorHex = $0.toHex() }
                            )
                        }
                    }
                    .padding(18)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(20)
                    .padding(.horizontal, 16)
                    
                    // 重置按钮
                    if manager.isEnabled {
                        Button(role: .destructive, action: {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            withAnimation(.easeInOut) { manager.resetToDefaults() }
                        }) {
                            Text("恢复默认无边框".tr)
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(14)
                        }
                        .padding(.horizontal, 16)
                    }
                }
                .padding(.bottom, 32)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("图标边框工作室".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
        }
        .presentationDetents([.large])
    }
    
    // 仿真真实手机桌面的预览画板
    private var canvasPreviewBox: some View {
        let s = uiScale
        return ZStack {
            // 背景壁纸
            Group {
                if let img = wallpaperManager.homeScreenImage {
                    Image(uiImage: img).resizable().scaledToFill()
                } else if let data = wallpaperManager.homeScreenData, let img = UIImage(data: data) {
                    Image(uiImage: img).resizable().scaledToFill()
                } else {
                    LinearGradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.6)], startPoint: .top, endPoint: .bottom)
                }
            }
            .frame(height: 220 * s)
            .clipped()
            
            // 覆盖一层轻微暗影以衬托图标
            Color.black.opacity(0.15)
            
            VStack(spacing: 18 * s) {
                // 上排：网格应用模拟
                HStack(spacing: 28 * s) {
                    demoIconItem(name: "微信".tr, icon: "message.fill", color: Color(hex: "#07C160"))
                    demoIconItem(name: "iScreen", icon: "square.grid.2x2.fill", color: .purple)
                }
                .padding(.top, 10 * s)
                
                // 下排：迷你仿真 Dock 栏
                HStack(spacing: 22 * s) {
                    demoDockIconItem(icon: "phone.fill", color: .green)
                    demoDockIconItem(icon: "message.badge.filled.fill", color: .green)
                }
                .padding(.horizontal, 22 * s)
                .padding(.vertical, 8 * s)
                .background(RoundedRectangle(cornerRadius: 24 * s, style: .continuous).fill(.ultraThinMaterial))
            }
        }
        .frame(height: 220 * s)
        .clipShape(RoundedRectangle(cornerRadius: 24 * s, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24 * s, style: .continuous)
                .stroke(Color.primary.opacity(0.08), lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)
    }
    
    private func demoIconItem(name: String, icon: String, color: Color) -> some View {
        let s = uiScale
        return VStack(spacing: 4 * s) {
            Image(systemName: icon)
                .font(.system(size: 28 * s))
                .foregroundColor(.white)
                .frame(width: 52 * s, height: 52 * s)
                .background(color)
                .clipShape(RoundedRectangle(cornerRadius: 14 * s, style: .continuous))
                .applyIconBorder(cornerRadius: 14)
            
            Text(name)
                .font(.system(size: 11 * s, weight: appearance.systemFontWeight))
                .foregroundColor(.white)
                .shadow(color: .black.opacity(0.4), radius: 2)
        }
    }
    
    private func demoDockIconItem(icon: String, color: Color) -> some View {
        let s = uiScale
        return Image(systemName: icon)
            .font(.system(size: 26 * s))
            .foregroundColor(.white)
            .frame(width: 48 * s, height: 48 * s)
            .background(color)
            .clipShape(RoundedRectangle(cornerRadius: 13 * s, style: .continuous))
            .applyIconBorder(cornerRadius: 13)
    }
}

// MARK: - 5. iScreen 工坊内的入口大卡片组件
public struct IconBorderStudioEntryCard: View {
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var borderManager = IconBorderManager.shared
    @State private var showSheet = false
    
    public init() {}
    
    public var body: some View {
        Button(action: {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            showSheet = true
        }) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(LinearGradient(colors: [.indigo, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 44, height: 44)
                    Image(systemName: "square.dashed")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text("桌面图标边框工作室".tr)
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Text(borderManager.isEnabled ? "已启用".tr : "未开启".tr)
                            .font(.system(size: 10, weight: .bold))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(borderManager.isEnabled ? Color.green.opacity(0.15) : Color(UIColor.tertiarySystemFill))
                            .foregroundColor(borderManager.isEnabled ? .green : .secondary)
                            .clipShape(Capsule())
                    }
                    Text("自定义全屏与 Dock 栏图标内描边、贴纸外边框".tr)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.secondary.opacity(0.6))
            }
            .padding(14)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.primary.opacity(0.06), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showSheet) {
            IconBorderStudioSheet(isPresented: $showSheet)
        }
    }
}
