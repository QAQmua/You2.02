// 📄 单独文件：MusicApp.swift
import SwiftUI

// 🌟 系统启动时自动扫描并装配到桌面
final class MusicAppRegistration: BaseAppPlugin {
    override class var id: String { "music_app" }
    override class var name: String { "网易云音乐" }
    override class var icon: String { "music.note" }
    override class var colorName: String { "red" }
    
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(MusicMainView(show: show))
    }
}

// 界面视图
struct MusicMainView: View {
    @Binding var show: Bool
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "music.quarternote.3")
                    .font(.system(size: 60))
                    .foregroundColor(.red)
                Text("正在播放：极客漫游指南 🎵")
                    .font(.headline)
            }
            .navigationTitle("音乐".tr)
            .navigationBarTitleDisplayMode(.inline)
        }
        // 自带的右滑退出能力
        .enableSwipeDismiss(show: $show)
    }
}
