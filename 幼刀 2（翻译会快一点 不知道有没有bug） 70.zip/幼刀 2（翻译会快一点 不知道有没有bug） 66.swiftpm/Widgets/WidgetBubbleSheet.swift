// 📄 完整替换文件：Widgets/WidgetBubbleSheet.swift
import SwiftUI
import PhotosUI

struct EditBubbleWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    
    @State private var selectedBubblePhotoItem: PhotosPickerItem? = nil
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    private let bubbleColorPresets = ["#E5E5EA", "#FFFFFF", "#1C1C1E", "#D0E1FD", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#E8DFF5"]
    private let textColorPresets = ["#000000", "#FFFFFF", "#3C3C43", "#007AFF", "#FF2D55", "#5856D6"]
    private let dateColorPresets = ["#8E8E93", "#000000", "#FFFFFF", "#007AFF", "#FF9500"]
    
    var body: some View {
        let s = uiScale
        
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    // 🌟 彻底去掉外层白框底板，本体直接悬浮展示
                    ChatBubbleWidget2x2View(
                        imageData: chatBubbleManager.widgetImageData,
                        firstBubbleText: chatBubbleManager.firstBubbleText,
                        secondBubbleText: chatBubbleManager.secondBubbleText,
                        isTransparent: chatBubbleManager.isTransparentBackground,
                        bubbleColor: chatBubbleManager.bubbleColor,
                        bubbleTextColor: chatBubbleManager.bubbleTextColor,
                        dateTextColor: chatBubbleManager.dateTextColor,
                        bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                        showDashedBorder: true
                    )
                    .frame(width: 160 * s, height: 160 * s)
                    .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 16)
                    .padding(.bottom, 6)
                    
                    VStack(spacing: 0) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("第一条文案".tr)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            
                            TextField("输入文案".tr, text: $chatBubbleManager.firstBubbleText)
                                .font(.subheadline)
                                .padding(10)
                                .background(Color(UIColor.tertiarySystemFill))
                                .cornerRadius(10)
                                .onChange(of: chatBubbleManager.firstBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        
                        Divider().padding(.leading, 16)
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("第二条文案".tr)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            
                            TextField("输入文案".tr, text: $chatBubbleManager.secondBubbleText)
                                .font(.subheadline)
                                .padding(10)
                                .background(Color(UIColor.tertiarySystemFill))
                                .cornerRadius(10)
                                .onChange(of: chatBubbleManager.secondBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    VStack(spacing: 0) {
                        PhotosPicker(selection: $selectedBubblePhotoItem, matching: .images, photoLibrary: .shared()) {
                            HStack {
                                Label("更换照片".tr, systemImage: "photo.badge.plus")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.semibold))
                                    .foregroundColor(.secondary)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 14)
                        }
                        .foregroundColor(.primary)
                        
                        Divider().padding(.leading, 16)
                        
                        Toggle(isOn: $chatBubbleManager.isTransparentBackground) {
                            Label("背景透明".tr, systemImage: "circle.lefthalf.filled")
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        Text("颜色与字体样式".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 16)
                            .padding(.top, 14)
                        
                        WidgetFontWeightPicker(title: "字体粗细".tr, selectedWeightName: $chatBubbleManager.bubbleTextWeightName)
                            .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "气泡颜色".tr,
                            selectedHex: chatBubbleManager.bubbleColorHex,
                            presets: bubbleColorPresets,
                            currentColor: chatBubbleManager.bubbleColor,
                            onSelectHex: { chatBubbleManager.bubbleColorHex = $0 },
                            onPickColor: { chatBubbleManager.bubbleColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "气泡文字".tr,
                            selectedHex: chatBubbleManager.textColorHex,
                            presets: textColorPresets,
                            currentColor: chatBubbleManager.bubbleTextColor,
                            onSelectHex: { chatBubbleManager.textColorHex = $0 },
                            onPickColor: { chatBubbleManager.textColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "顶部日期".tr,
                            selectedHex: chatBubbleManager.dateColorHex,
                            presets: dateColorPresets,
                            currentColor: chatBubbleManager.dateTextColor,
                            onSelectHex: { chatBubbleManager.dateColorHex = $0 },
                            onPickColor: { chatBubbleManager.dateColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 14)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                }
                .padding(.bottom, 32)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("对话框".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
        }
        .presentationDetents([.medium, .large])
        .task(id: selectedBubblePhotoItem) {
            if let data = try? await selectedBubblePhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) { chatBubbleManager.widgetImageData = data }
            }
        }
    }
}
