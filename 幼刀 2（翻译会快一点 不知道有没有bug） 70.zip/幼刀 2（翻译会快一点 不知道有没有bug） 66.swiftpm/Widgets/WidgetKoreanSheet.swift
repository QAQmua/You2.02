// 📄 完整替换文件：Widgets/WidgetKoreanSheet.swift
import SwiftUI
import PhotosUI

struct EditKoreanWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = KoreanMessageWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @ObservedObject var appearance = SystemAppearance.shared
    
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let bgPresets = ["#EDEDF2", "#FFFFFF", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#E5E5EA", "#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let boxStyleOptions = [("柔和阴影", "shadow"), ("描边", "border"), ("无", "none")]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 🌟 方案 3：纯净自然留白（无分割线、无渐变，纯靠舒适呼吸间距）
                if widgetManager.isPinPreviewToTop {
                    previewCardView
                        .background(Color(UIColor.systemGroupedBackground))
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !widgetManager.isPinPreviewToTop {
                            previewCardView
                        }
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("背景与显示".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.isPinPreviewToTop) {
                                Label("固定顶部预览".tr, systemImage: "pin.fill").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            Divider()
                            Toggle(isOn: $widgetManager.isTransparentBackground) {
                                Label("背景透明".tr, systemImage: "circle.lefthalf.filled").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if !widgetManager.isTransparentBackground {
                                Divider()
                                WidgetColorPaletteRow(title: "背景底色".tr, selectedHex: widgetManager.backgroundColorHex, presets: bgPresets, currentColor: widgetManager.backgroundColor, onSelectHex: { widgetManager.backgroundColorHex = $0 }, onPickColor: { widgetManager.backgroundColorHex = $0.toHex() })
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 8) {
                                Text("白框效果".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                HStack(spacing: 8) {
                                    ForEach(boxStyleOptions, id: \.1) { item in
                                        let isSelected = widgetManager.boxStyle == item.1
                                        Button(action: {
                                            withAnimation(.easeInOut(duration: 0.18)) { widgetManager.boxStyle = item.1 }
                                        }) {
                                            Text(item.0.tr)
                                                .font(.system(size: 12, weight: isSelected ? .semibold : appearance.systemFontWeight))
                                                .padding(.horizontal, 12).padding(.vertical, 6)
                                                .background(isSelected ? Color.blue : Color(UIColor.tertiarySystemFill))
                                                .foregroundColor(isSelected ? .white : .primary)
                                                .clipShape(Capsule())
                                        }
                                    }
                                }
                                if widgetManager.boxStyle == "border" {
                                    Divider().padding(.top, 4)
                                    VStack(alignment: .leading, spacing: 6) {
                                        HStack {
                                            Text("白框描边粗细".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                            Spacer()
                                            Text(String(format: "%.1f pt", widgetManager.boxBorderWidth)).font(.caption).foregroundColor(.secondary)
                                        }
                                        Slider(value: $widgetManager.boxBorderWidth, in: 0.1...5.0, step: 0.1)
                                    }
                                    Divider()
                                    WidgetColorPaletteRow(title: "白框描边颜色".tr, selectedHex: widgetManager.boxBorderColorHex, presets: borderPresets, currentColor: widgetManager.boxBorderColor, onSelectHex: { widgetManager.boxBorderColorHex = $0 }, onPickColor: { widgetManager.boxBorderColorHex = $0.toHex() })
                                }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("头像与印章".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换头像".tr, systemImage: "photo.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("头像大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.avatarSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.avatarSize, in: 28...50, step: 1)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("印章图标大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.sealSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sealSize, in: 14...30, step: 1)
                            }
                            Divider()
                            WidgetColorPaletteRow(title: "印章图标颜色".tr, selectedHex: widgetManager.sealColorHex, presets: textColors, currentColor: widgetManager.sealColor, onSelectHex: { widgetManager.sealColorHex = $0 }, onPickColor: { widgetManager.sealColorHex = $0.toHex() })
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "顶部标题".tr, placeholder: "如：보내기 ♡", text: $widgetManager.headerTitle, size: $widgetManager.headerSize, minSize: 7, maxSize: 18, selectedWeightName: $widgetManager.headerWeightName, selectedHex: widgetManager.headerColorHex, currentColor: widgetManager.headerColor, onSelectHex: { widgetManager.headerColorHex = $0 }, onPickColor: { widgetManager.headerColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "个人昵称".tr, placeholder: "如：디저트", text: $widgetManager.profileName, size: $widgetManager.nameSize, minSize: 9, maxSize: 20, selectedWeightName: $widgetManager.nameWeightName, selectedHex: widgetManager.nameColorHex, currentColor: widgetManager.nameColor, onSelectHex: { widgetManager.nameColorHex = $0 }, onPickColor: { widgetManager.nameColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第一排左侧文案".tr, placeholder: "如：고생 끝에 낙이 온达", text: $widgetManager.firstBarLeftText, size: $widgetManager.leftSize, minSize: 9, maxSize: 18, selectedWeightName: $widgetManager.leftWeightName, selectedHex: widgetManager.leftColorHex, currentColor: widgetManager.leftColor, onSelectHex: { widgetManager.leftColorHex = $0 }, onPickColor: { widgetManager.leftColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第一排右侧文案".tr, placeholder: "如：슬프다", text: $widgetManager.firstBarRightText, size: $widgetManager.rightSize, minSize: 8, maxSize: 16, selectedWeightName: $widgetManager.rightWeightName, selectedHex: widgetManager.rightColorHex, currentColor: widgetManager.rightColor, onSelectHex: { widgetManager.rightColorHex = $0 }, onPickColor: { widgetManager.rightColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第二排签名/账号".tr, placeholder: "如：kunoouc", text: $widgetManager.secondBarText, size: $widgetManager.secondSize, minSize: 9, maxSize: 18, selectedWeightName: $widgetManager.secondWeightName, selectedHex: widgetManager.secondColorHex, currentColor: widgetManager.secondColor, onSelectHex: { widgetManager.secondColorHex = $0 }, onPickColor: { widgetManager.secondColorHex = $0.toHex() })
                    }
                    .padding(.bottom, 32)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("寄语卡片".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
        }
        .presentationDetents([.medium, .large])
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) { widgetManager.widgetImageData = data }
            }
        }
    }
    
    private var previewCardView: some View {
        let s = uiScale
        return KoreanMessageWidget4x2View(
            manager: widgetManager,
            showDashedBorder: true
        )
        .frame(height: 156 * s)
        .shadow(color: Color.black.opacity(0.06), radius: 8, y: 3)
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .padding(.bottom, 16) // 🌟 纯净呼吸留白
    }
}
