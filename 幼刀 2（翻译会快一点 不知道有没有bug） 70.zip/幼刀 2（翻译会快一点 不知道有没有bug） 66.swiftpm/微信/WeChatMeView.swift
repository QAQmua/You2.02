import SwiftUI

// 📄 微信“我”独立视图
struct WeChatMeView: View {
    @Binding var isLoggedIn: Bool
    
    var body: some View {
        List {
            Section {
                HStack(spacing: 16) {
                    Image(systemName: "person.crop.square.fill")
                        .resizable().frame(width: 64, height: 64)
                        .foregroundColor(.gray.opacity(0.5)).cornerRadius(8)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("幼".tr).font(.system(size: 20, weight: .semibold))
                        HStack {
                            Text("微信号：kunoouc".tr).font(.system(size: 14)).foregroundColor(.secondary)
                            Spacer()
                            Image(systemName: "qrcode").foregroundColor(.secondary)
                            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
                        }
                    }
                }
                .padding(.vertical, 14)
            }
            
            Section {
                settingRow(icon: "creditcard.fill", color: Color(hex: "#07C160"), title: "服务".tr)
            }
            
            Section {
                settingRow(icon: "cube.box.fill", color: .yellow, title: "收藏".tr)
                settingRow(icon: "photo.fill", color: .blue, title: "朋友圈".tr)
                settingRow(icon: "lanyardcard.fill", color: .blue, title: "卡包".tr)
                settingRow(icon: "face.smiling.fill", color: .orange, title: "表情".tr)
            }
            
            Section {
                settingRow(icon: "gearshape.fill", color: .blue, title: "设置".tr)
            }
            
            Section {
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = false }
                }) {
                    Text("退出登录".tr).font(.system(size: 16)).foregroundColor(.red).frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
        .listStyle(.insetGrouped)
    }
    
    private func settingRow(icon: String, color: Color, title: String) -> some View {
        HStack {
            Image(systemName: icon).foregroundColor(color).frame(width: 24, height: 24)
            Text(title).font(.system(size: 16))
            Spacer()
            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
        }
        .padding(.vertical, 2)
    }
}
